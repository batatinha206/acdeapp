function PageNoteFound() {
    return ( 
        <h1>Erro 404</h1>
     );
}

export default PageNoteFound;