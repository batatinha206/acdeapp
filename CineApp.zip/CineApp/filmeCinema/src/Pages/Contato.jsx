function Contato() {
    return ( 
        <h1>Contato</h1>
     );
}

export default Contato;